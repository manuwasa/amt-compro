<button <?php echo e($attributes->merge(['type' => 'submit', 'class' => 'inline-flex items-center px-5 py-2.5 bg-red-600 rounded-full font-semibold text-sm text-white hover:bg-red-500 active:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 transition-colors duration-200'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH C:\laragon\www\amt-compro\resources\views/components/danger-button.blade.php ENDPATH**/ ?>