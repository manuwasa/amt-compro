<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['title' => 'Admin']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['title' => 'Admin']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="robots" content="noindex, nofollow">
    <title><?php echo e($title); ?> — Admin — <?php echo e($groupSettings['group_name'] ?? config('app.name')); ?></title>

    <script>document.documentElement.classList.add('reveal-ready')</script>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="min-h-screen bg-slate-50 text-slate-900 antialiased font-sans" x-data="{ sidebarOpen: false }">

    <?php
        $navItems = [
            ['label' => 'Dashboard', 'route' => 'admin.dashboard', 'active' => 'admin.dashboard'],
            ['label' => 'Companies', 'route' => 'admin.companies.index', 'active' => 'admin.companies.*'],
            ['label' => 'Products', 'route' => 'admin.products.index', 'active' => 'admin.products.*'],
            ['label' => 'Articles', 'route' => 'admin.articles.index', 'active' => 'admin.articles.*'],
            ['label' => 'Messages', 'route' => 'admin.messages.index', 'active' => 'admin.messages.*'],
        ];
    ?>

    <!-- Mobile sidebar backdrop -->
    <div x-show="sidebarOpen" x-cloak x-transition.opacity @click="sidebarOpen = false" class="fixed inset-0 z-40 bg-slate-900/50 lg:hidden"></div>

    <div class="flex min-h-screen">
        <aside
            class="fixed inset-y-0 left-0 z-50 w-64 shrink-0 bg-slate-900 text-slate-300 flex flex-col transform transition-transform duration-300 lg:translate-x-0"
            :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full'"
        >
            <div class="h-16 flex items-center px-6 gap-2.5 text-white font-display font-bold shrink-0">
                <span class="flex h-8 w-8 items-center justify-center rounded-lg bg-brand-500 text-slate-900 text-sm">
                    <?php echo e(mb_substr($groupSettings['group_name'] ?? config('app.name'), 0, 1)); ?>

                </span>
                <span class="truncate"><?php echo e($groupSettings['group_name'] ?? config('app.name')); ?></span>
            </div>

            <nav class="flex-1 px-3 space-y-0.5 text-sm overflow-y-auto">
                <?php $__currentLoopData = $navItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route($item['route'])); ?>" class="block rounded-lg px-3.5 py-2.5 border-l-2 transition-colors <?php echo e(request()->routeIs($item['active']) ? 'border-brand-500 bg-white/5 text-white' : 'border-transparent text-slate-400 hover:bg-white/5 hover:text-white'); ?>">
                        <?php echo e($item['label']); ?>

                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if(auth()->user()?->isSuperAdmin()): ?>
                    <div class="pt-5 mt-4 border-t border-white/10 text-xs font-semibold uppercase tracking-wider text-slate-500 px-3.5 pb-1">Superadmin</div>
                    <a href="<?php echo e(route('admin.settings.edit')); ?>" class="block rounded-lg px-3.5 py-2.5 border-l-2 transition-colors <?php echo e(request()->routeIs('admin.settings.*') ? 'border-brand-500 bg-white/5 text-white' : 'border-transparent text-slate-400 hover:bg-white/5 hover:text-white'); ?>">Group Settings</a>
                    <a href="<?php echo e(route('admin.users.index')); ?>" class="block rounded-lg px-3.5 py-2.5 border-l-2 transition-colors <?php echo e(request()->routeIs('admin.users.*') ? 'border-brand-500 bg-white/5 text-white' : 'border-transparent text-slate-400 hover:bg-white/5 hover:text-white'); ?>">Users</a>
                <?php endif; ?>
            </nav>

            <div class="p-3 border-t border-white/10 shrink-0">
                <a href="<?php echo e(route('home')); ?>" class="flex items-center gap-2 rounded-lg px-3.5 py-2.5 text-sm text-slate-400 hover:bg-white/5 hover:text-white transition-colors">
                    <span aria-hidden="true">&larr;</span> Back to site
                </a>
            </div>
        </aside>

        <div class="flex-1 flex flex-col min-w-0 lg:ml-64">
            <header class="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-4 sm:px-6 shrink-0">
                <div class="flex items-center gap-3">
                    <button @click="sidebarOpen = true" type="button" class="lg:hidden -ml-1 p-2 rounded-lg text-slate-500 hover:bg-slate-100" aria-label="Open menu">
                        <svg class="h-5 w-5" stroke="currentColor" fill="none" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
                        </svg>
                    </button>
                    <h1 class="text-lg font-semibold tracking-tight"><?php echo e($title); ?></h1>
                </div>

                <div class="flex items-center gap-3 text-sm">
                    <div class="hidden sm:flex items-center gap-2.5">
                        <span class="flex h-8 w-8 items-center justify-center rounded-full bg-slate-900 text-white text-xs font-semibold">
                            <?php echo e(mb_substr(auth()->user()?->name ?? '?', 0, 1)); ?>

                        </span>
                        <div class="leading-tight">
                            <div class="font-medium text-slate-900"><?php echo e(auth()->user()?->name); ?></div>
                            <div class="text-xs text-slate-400 capitalize"><?php echo e(auth()->user()?->role); ?></div>
                        </div>
                    </div>
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="rounded-lg px-3 py-1.5 text-slate-500 hover:bg-slate-100 hover:text-slate-900 transition-colors">Log out</button>
                    </form>
                </div>
            </header>

            <main class="flex-1 p-4 sm:p-6">
                <?php if(session('status')): ?>
                    <div class="mb-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-sm px-4 py-3">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>

                <?php if(session('error')): ?>
                    <div class="mb-4 rounded-xl bg-red-50 border border-red-200 text-red-800 text-sm px-4 py-3">
                        <?php echo e(session('error')); ?>

                    </div>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                    <div class="mb-4 rounded-xl bg-red-50 border border-red-200 text-red-800 text-sm px-4 py-3">
                        <ul class="list-disc pl-5 space-y-1">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <?php echo e($slot); ?>

            </main>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\laragon\www\amt-compro\resources\views/components/admin-layout.blade.php ENDPATH**/ ?>