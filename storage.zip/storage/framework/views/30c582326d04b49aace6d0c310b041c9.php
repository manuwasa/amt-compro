<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'title' => null,
    'description' => null,
    'image' => null,
    'type' => 'website',
    'canonical' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'title' => null,
    'description' => null,
    'image' => null,
    'type' => 'website',
    'canonical' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $groupName = $groupSettings['group_name'] ?? config('app.name');
    $resolvedTitle = $title ? "{$title} — {$groupName}" : $groupName;
    $resolvedDescription = $description ?: ($groupSettings['meta_description'] ?? null);
    $resolvedImage = $image ?: ($groupSettings['group_logo'] ?? null);
    $resolvedImageUrl = $resolvedImage ? \Illuminate\Support\Facades\Storage::url($resolvedImage) : null;
    $resolvedCanonical = $canonical ?: url()->current();
?>

<title><?php echo e($resolvedTitle); ?></title>
<?php if($resolvedDescription): ?>
    <meta name="description" content="<?php echo e($resolvedDescription); ?>">
<?php endif; ?>
<link rel="canonical" href="<?php echo e($resolvedCanonical); ?>">

<meta property="og:site_name" content="<?php echo e($groupName); ?>">
<meta property="og:type" content="<?php echo e($type); ?>">
<meta property="og:title" content="<?php echo e($resolvedTitle); ?>">
<?php if($resolvedDescription): ?>
    <meta property="og:description" content="<?php echo e($resolvedDescription); ?>">
<?php endif; ?>
<meta property="og:url" content="<?php echo e($resolvedCanonical); ?>">
<?php if($resolvedImageUrl): ?>
    <meta property="og:image" content="<?php echo e($resolvedImageUrl); ?>">
<?php endif; ?>

<meta name="twitter:card" content="<?php echo e($resolvedImageUrl ? 'summary_large_image' : 'summary'); ?>">
<meta name="twitter:title" content="<?php echo e($resolvedTitle); ?>">
<?php if($resolvedDescription): ?>
    <meta name="twitter:description" content="<?php echo e($resolvedDescription); ?>">
<?php endif; ?>
<?php if($resolvedImageUrl): ?>
    <meta name="twitter:image" content="<?php echo e($resolvedImageUrl); ?>">
<?php endif; ?>
<?php /**PATH C:\laragon\www\amt-compro\resources\views/components/seo-meta.blade.php ENDPATH**/ ?>