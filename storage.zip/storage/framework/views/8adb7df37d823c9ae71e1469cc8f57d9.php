<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    
    <script>
        document.documentElement.classList.add('reveal-ready')
    </script>

    <?php if (isset($component)) { $__componentOriginal84f9df3f620371229981225e7ba608d7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal84f9df3f620371229981225e7ba608d7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.seo-meta','data' => ['title' => $title ?? null,'description' => $description ?? null,'image' => $image ?? null,'type' => $ogType ?? 'website']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('seo-meta'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title ?? null),'description' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($description ?? null),'image' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($image ?? null),'type' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($ogType ?? 'website')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal84f9df3f620371229981225e7ba608d7)): ?>
<?php $attributes = $__attributesOriginal84f9df3f620371229981225e7ba608d7; ?>
<?php unset($__attributesOriginal84f9df3f620371229981225e7ba608d7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal84f9df3f620371229981225e7ba608d7)): ?>
<?php $component = $__componentOriginal84f9df3f620371229981225e7ba608d7; ?>
<?php unset($__componentOriginal84f9df3f620371229981225e7ba608d7); ?>
<?php endif; ?>

    <?php echo $__env->yieldPushContent('jsonld'); ?>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>

<body class="min-h-screen flex flex-col bg-white text-slate-900 antialiased font-sans">

    <header x-data="{ open: false, scrolled: false }" x-init="window.addEventListener('scroll', () => scrolled = window.scrollY > 12)" class="sticky top-0 z-40 transition-all duration-300"
        :class="scrolled ? 'bg-white/90 backdrop-blur-md border-b border-slate-200 shadow-sm' :
            'bg-white/0 border-b border-transparent'">
        <nav class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
            
            <a href="<?php echo e(route('home')); ?>" class="font-display font-bold text-lg text-slate-900 shrink-0">
                <?php echo e($groupSettings['group_name'] ?? config('app.name')); ?>

            </a>

            <div class="hidden lg:flex items-center gap-1 text-sm font-medium">
                <?php $__currentLoopData = [['label' => 'Home', 'route' => 'home', 'active' => 'home'], ['label' => 'Our Services', 'route' => 'companies.index', 'active' => 'companies.*'], ['label' => 'Products', 'route' => 'products.index', 'active' => 'products.*'], ['label' => 'News & Artikel', 'route' => 'articles.index', 'active' => 'articles.*']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route($link['route'])); ?>"
                        class="group relative px-4 py-2 <?php echo e(request()->routeIs($link['active']) ? 'text-slate-900' : 'text-slate-500 hover:text-slate-900'); ?>">
                        <?php echo e($link['label']); ?>

                        <span
                            class="absolute left-4 right-4 -bottom-0.5 h-0.5 rounded-full bg-brand-500 origin-left transition-transform duration-300 <?php echo e(request()->routeIs($link['active']) ? 'scale-x-100' : 'scale-x-0 group-hover:scale-x-100'); ?>"></span>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="hidden lg:block">
                <?php if (isset($component)) { $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['variant' => 'primary','href' => ''.e(route('contact')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'primary','href' => ''.e(route('contact')).'']); ?>
                    Contact Us
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $attributes = $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $component = $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
            </div>

            <button @click="open = ! open" type="button"
                class="lg:hidden relative h-10 w-10 flex items-center justify-center rounded-full text-slate-700 hover:bg-slate-100"
                aria-label="Toggle menu">
                <svg class="h-6 w-6 transition-all duration-300"
                    :class="open ? 'rotate-90 scale-0 opacity-0 absolute' : 'rotate-0 scale-100 opacity-100'"
                    stroke="currentColor" fill="none" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
                </svg>
                <svg class="h-6 w-6 transition-all duration-300"
                    :class="open ? 'rotate-0 scale-100 opacity-100' : '-rotate-90 scale-0 opacity-0 absolute'"
                    stroke="currentColor" fill="none" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                </svg>
            </button>
        </nav>

        <div x-show="open" x-transition:enter="transition ease-out duration-200"
            x-transition:enter-start="opacity-0 -translate-y-2" x-transition:enter-end="opacity-100 translate-y-0"
            x-transition:leave="transition ease-in duration-150" x-transition:leave-start="opacity-100 translate-y-0"
            x-transition:leave-end="opacity-0 -translate-y-2" x-cloak
            class="lg:hidden bg-white border-b border-slate-200 shadow-lg px-4 sm:px-6 py-4 space-y-1 text-sm font-medium">
            <a href="<?php echo e(route('home')); ?>"
                class="block rounded-lg px-3 py-2.5 <?php echo e(request()->routeIs('home') ? 'bg-slate-100 text-slate-900' : 'text-slate-600'); ?>">Home</a>
            <a href="<?php echo e(route('companies.index')); ?>"
                class="block rounded-lg px-3 py-2.5 <?php echo e(request()->routeIs('companies.*') ? 'bg-slate-100 text-slate-900' : 'text-slate-600'); ?>">Our
                Services</a>
            <a href="<?php echo e(route('products.index')); ?>"
                class="block rounded-lg px-3 py-2.5 <?php echo e(request()->routeIs('products.*') ? 'bg-slate-100 text-slate-900' : 'text-slate-600'); ?>">Products</a>
            <a href="<?php echo e(route('articles.index')); ?>"
                class="block rounded-lg px-3 py-2.5 <?php echo e(request()->routeIs('articles.*') ? 'bg-slate-100 text-slate-900' : 'text-slate-600'); ?>">News
                &amp; Artikel</a>
            <a href="<?php echo e(route('contact')); ?>"
                class="block rounded-lg px-3 py-2.5 <?php echo e(request()->routeIs('contact') ? 'bg-slate-100 text-slate-900' : 'text-slate-600'); ?>">Contact
                Us</a>
        </div>
    </header>

    <main class="flex-1">
        <?php if(session('status')): ?>
            <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 mt-6" data-reveal>
                <div class="rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-sm px-4 py-3">
                    <?php echo e(session('status')); ?>

                </div>
            </div>
        <?php endif; ?>

        <?php echo e($slot); ?>

    </main>

    <footer class="bg-slate-900 text-slate-300 mt-24">
        <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-16 grid gap-8 sm:grid-cols-2 lg:grid-cols-5">
            <div class="lg:col-span-1">
                <div class="flex items-center gap-2.5 font-display font-bold text-lg text-white mb-3">
                    <?php if(!empty($groupSettings['group_logo'])): ?>
                        <img src="<?php echo e(\Illuminate\Support\Facades\Storage::url($groupSettings['group_logo'])); ?>"
                            alt="<?php echo e($groupSettings['group_name'] ?? config('app.name')); ?>" class="h-8 w-auto">
                    <?php endif; ?>
                    <span><?php echo e($groupSettings['group_name'] ?? config('app.name')); ?></span>
                </div>
                <p class="text-sm text-slate-400 leading-relaxed"><?php echo e($groupSettings['group_tagline'] ?? ''); ?></p>
            </div>

            <div>
                <div class="font-semibold text-white mb-4 text-sm uppercase tracking-wider">Our Services</div>
                <ul class="space-y-2.5 text-sm">
                    <?php $__currentLoopData = $activeCompanies ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activeCompany): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(route('companies.show', $activeCompany)); ?>"
                                class="text-slate-400 hover:text-brand-400 transition-colors"><?php echo e($activeCompany->name); ?></a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>

            <div>
                <div class="font-semibold text-white mb-4 text-sm uppercase tracking-wider">Explore</div>
                <ul class="space-y-2.5 text-sm">
                    <li><a href="<?php echo e(route('companies.index')); ?>"
                            class="text-slate-400 hover:text-brand-400 transition-colors">Our Services</a></li>
                    <li><a href="<?php echo e(route('products.index')); ?>"
                            class="text-slate-400 hover:text-brand-400 transition-colors">Products</a></li>
                    <li><a href="<?php echo e(route('articles.index')); ?>"
                            class="text-slate-400 hover:text-brand-400 transition-colors">News &amp; Artikel</a></li>
                    <li><a href="<?php echo e(route('contact')); ?>"
                            class="text-slate-400 hover:text-brand-400 transition-colors">Contact Us</a></li>
                </ul>
            </div>

            <div>
                <div class="font-semibold text-white mb-4 text-sm uppercase tracking-wider">Address</div>
                <ul class="space-y-2.5 text-sm">
                    <li><a href="#" class="text-slate-400 hover:text-brand-400 transition-colors">Jl. Teuku Umar,
                            Gg. Kantor Pos
                            RT.004 RW.005 DS. Telaga Asih, Kec. Cikarang, Kab. Bekasi</a></li>
                    <li><a href="#" class="text-slate-400 hover:text-brand-400 transition-colors">021 221 627
                            22</a></li>
                    <li><a href="#"
                            class="text-slate-400 hover:text-brand-400 transition-colors">abc.official@sabcjaya.co.id</a>
                    </li>

                </ul>
            </div>

            <div>
                <div class="font-semibold text-white mb-4 text-sm uppercase tracking-wider">Contact</div>
                <ul class="space-y-2.5 text-sm">
                    <?php if(!empty($groupSettings['group_email'])): ?>
                        <li><a href="mailto:<?php echo e($groupSettings['group_email']); ?>"
                                class="text-slate-400 hover:text-brand-400 transition-colors"><?php echo e($groupSettings['group_email']); ?></a>
                        </li>
                    <?php endif; ?>
                    <?php if(!empty($groupSettings['group_whatsapp_number'])): ?>
                        <li><a href="https://wa.me/<?php echo e(preg_replace('/\D/', '', $groupSettings['group_whatsapp_number'])); ?>"
                                class="text-slate-400 hover:text-brand-400 transition-colors" target="_blank"
                                rel="noopener">WhatsApp</a></li>
                    <?php endif; ?>
                    <?php if(empty($groupSettings['group_email']) && empty($groupSettings['group_whatsapp_number'])): ?>
                        <li><a href="<?php echo e(route('contact')); ?>"
                                class="text-slate-400 hover:text-brand-400 transition-colors">Get in touch &rarr;</a>
                        </li>
                    <?php endif; ?>
                </ul>

                <?php if(!empty($groupSettings['social_instagram_url']) || !empty($groupSettings['social_tiktok_url'])): ?>
                    <div class="flex gap-2 mt-5">
                        <?php if(!empty($groupSettings['social_instagram_url'])): ?>
                            <a href="<?php echo e($groupSettings['social_instagram_url']); ?>" target="_blank" rel="noopener"
                                class="rounded-full border border-slate-700 px-3.5 py-1.5 text-xs font-medium text-slate-300 hover:border-brand-500 hover:text-brand-400 transition-colors">Instagram</a>
                        <?php endif; ?>
                        <?php if(!empty($groupSettings['social_tiktok_url'])): ?>
                            <a href="<?php echo e($groupSettings['social_tiktok_url']); ?>" target="_blank" rel="noopener"
                                class="rounded-full border border-slate-700 px-3.5 py-1.5 text-xs font-medium text-slate-300 hover:border-brand-500 hover:text-brand-400 transition-colors">Tiktok</a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="border-t border-slate-800 py-6">
            <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-xs text-slate-500">
                &copy; <?php echo e(date('Y')); ?> <?php echo e($groupSettings['group_name'] ?? config('app.name')); ?>. All rights
                reserved.
            </div>
            <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-xs text-slate-500">
                <a href="https://www.putrateknologiindonesia.com">
                    Crafted With ♥ by putrateknologiindonesia.
                </a>
            </div>
        </div>
    </footer>

</body>

</html>
<?php /**PATH C:\laragon\www\amt-compro\resources\views/components/public-layout.blade.php ENDPATH**/ ?>